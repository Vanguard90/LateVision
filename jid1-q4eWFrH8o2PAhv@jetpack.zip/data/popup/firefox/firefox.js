var background = {
  "send": function (id, data) {self.port.emit(id, data)},
  "receive": function (id, callback) {self.port.on(id, callback)}
};

self.port.on("show", function () {background.send("load")});

window.addEventListener("resize", function () {
  self.port.emit("resize", {
    "w": document.body.getBoundingClientRect().width,
    "h": document.body.getBoundingClientRect().height
  });
}, false);