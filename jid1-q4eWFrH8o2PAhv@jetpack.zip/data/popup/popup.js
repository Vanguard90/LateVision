var globalR = 255, globalG = 147, globalB = 41, globalA = 100, globalMode = "on";
/*  */
var _toggle = function (flag) {
  var lightsOn = document.getElementById("lights-on");
  var lightsOff = document.getElementById("lights-off");
  /*  */
  if (flag === "on") {
    lightsOn.setAttribute("active", "true");
    lightsOff.setAttribute("active", "false");
    document.getElementById("info-td").textContent = "No Color Temperature (Ctrl+Shift+S)";
  } else {
    lightsOn.setAttribute("active", "false");
    lightsOff.setAttribute("active", "true"); 
    document.getElementById("info-td").textContent = "Color Temperature: " + "Red " + globalR + ', ' + "Green " + globalG + ', ' + "Blue " + globalB + ', ' + "Opacity " + globalA + "%";
  }
};
/*  */
var backgroundSend = function () {
  var _obj = {"R": globalR, "G": globalG, "B": globalB, "A": globalA, "mode": globalMode};
  background.send("storePopupData", _obj);
};
/*  */
var _init = function () {
  var R = document.getElementById("R-slider");
  var G = document.getElementById("G-slider");
  var B = document.getElementById("B-slider");
  var A = document.getElementById("A-slider");
  var options = document.getElementById("options");
  var support = document.getElementById("support");
  var lightsOn = document.getElementById("lights-on");
  var _add = document.getElementById("add-whitelist");
  var lightsOff = document.getElementById("lights-off");
  var _remove = document.getElementById("remove-whitelist");
  /*  */
  var handleClick = function (e) {
    var target = e.target || e.originalTarget;
    globalMode = target.getAttribute("type");
    _toggle(globalMode);
    backgroundSend();
  };
  /*  */
  var handleChange = function (e) {
    var target = e.target || e.originalTarget;
    var id = target.getAttribute("id");
    if (id.indexOf("R-") !== -1) globalR = target.value;
    else if (id.indexOf("G-") !== -1) globalG = target.value;
    else if (id.indexOf("B-") !== -1) globalB = target.value;
    else if (id.indexOf("A-") !== -1) globalA = target.value;
    else if (id.indexOf("-on") !== -1) globalMode = "on";
    else if (id.indexOf("-off") !== -1) globalMode = "off";
    /*  */
    _toggle(globalMode);
    backgroundSend();
  };
  /*  */
  R.addEventListener("input", handleChange);
  G.addEventListener("input", handleChange);
  B.addEventListener("input", handleChange);
  A.addEventListener("input", handleChange);
  lightsOn.addEventListener("click", handleClick);
  lightsOff.addEventListener("click", handleClick);
  /*  */
  options.addEventListener("click", function () {background.send("options")});
  support.addEventListener("click", function () {background.send("support")});
  _add.addEventListener("click", function () {background.send("add-whitelist")});
  _remove.addEventListener("click", function () {background.send("remove-whitelist")});
  /*  */
  background.receive("storageData", function (data) {
    globalR = data.R;
    globalG = data.G;
    globalB = data.B;
    globalA = data.A;
    globalMode = data.mode;
    /*  */
    _toggle(globalMode);
    R.value = globalR;
    G.value = globalG;
    B.value = globalB;
    A.value = globalA;
  });
  /*  */
  window.removeEventListener("load", _init, false);
};
/*  */
window.addEventListener("load", _init, false);