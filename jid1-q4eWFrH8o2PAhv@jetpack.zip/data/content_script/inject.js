var style = document.getElementById("screen-color-temperature-style");
var overlay = document.getElementById("screen-color-temperature-overlay");
var head = document.documentElement || document.head || document.querySelector("head");

if (!overlay) {
  overlay = document.createElement("div");
  overlay.setAttribute("class", "s-c-t");
  overlay.setAttribute("id", "screen-color-temperature-overlay");
  if (head) head.insertBefore(overlay, head.firstChild);
}

if (!style) {
  style = document.createElement("style");
  style.setAttribute("type", "text/css");
  style.setAttribute("id", "screen-color-temperature-style");
  if (head) head.insertBefore(style, head.firstChild);
}

var addStyle = function (o) {
  var R = o.R;
  var G = o.G;
  var B = o.B;
  var A = o.A;
  var mode = o.mode;
  /*  */
  style.textContent = '';
  var whitelist = o.whitelist ? o.whitelist : '';
  var permission = o.top ? (whitelist.indexOf(o.top) === -1) : true;
  if (!permission) return;
  /*  */
  var _main = document.location.href.indexOf("about:") !== -1 ? "body" : "html";
  if (window === window.top) {
    if (mode === "off") {
      style.textContent = 
        '.s-c-t {' + 
        '  top: -10% !important;' + 
        '  margin: 0 !important;' + 
        '  opacity: 1 !important;' + 
        '  padding: 0 !important;' + 
        '  right: -10% !important;' + 
        '  width: 120% !important;' + 
        '  height: 120% !important;' + 
        '  display: block !important;' + 
        '  position: fixed !important;' + 
        '  border-radius: 0 !important;' + 
        '  z-index: 2147483647 !important;' + 
        '  pointer-events: none !important;' + 
        '  transition: opacity 0.1s !important;' + 
        '  mix-blend-mode: multiply !important;' + 
        '  background: rgba(' + R + ', ' + G + ', ' + B + ', ' + (A / 100) + ') !important;' + 
        '}';
    } else style.textContent = '';
  }
};