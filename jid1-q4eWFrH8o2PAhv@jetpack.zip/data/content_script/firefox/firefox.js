var background = {
  "send": function (id, data) {self.port.emit(id, data)},
  "receive": function (id, callback) {
    self.port.on(id, function (o) {callback(o ? o.data : null)});
  }
};

var manifest = {"url": (self.options ? self.options.base : '')};
if (self.options) window.setTimeout(function () {addStyle(self.options)}, 10);

background.receive("storageData", addStyle);
self.port.on("tabId", function (o) {background.send("storageData", o)});